"use client"

import { useState, useRef, useEffect } from "react"
import { Bot, Send, Sparkles, User, Dumbbell, Utensils, Brain, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

const suggestedPrompts = [
  { icon: Dumbbell, text: "Create a workout plan for muscle building" },
  { icon: Utensils, text: "What should I eat before a morning workout?" },
  { icon: Brain, text: "How can I improve my recovery?" },
  { icon: Zap, text: "Analyze my progress this month" },
]

const initialMessages: Message[] = [
  {
    id: "1",
    role: "assistant",
    content: "Hello! I'm your AI fitness coach. I can help you with personalized workout plans, nutrition advice, recovery strategies, and progress analysis. What would you like to work on today?",
    timestamp: new Date()
  }
]

export function AIChat() {
  const [messages, setMessages] = useState<Message[]>(initialMessages)
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const generateResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase()
    
    if (lowerMessage.includes("workout") || lowerMessage.includes("exercise") || lowerMessage.includes("muscle")) {
      return "Based on your goals and current fitness level, I recommend a Push/Pull/Legs split with progressive overload. Here's today's focus:\n\n**Push Day (Chest & Triceps)**\n• Bench Press: 4×8-10 @ 185 lbs\n• Incline Dumbbell Press: 3×10-12\n• Cable Flyes: 3×12-15\n• Tricep Pushdowns: 3×12-15\n\nWould you like me to adjust the intensity or suggest alternatives?"
    }
    
    if (lowerMessage.includes("eat") || lowerMessage.includes("nutrition") || lowerMessage.includes("diet") || lowerMessage.includes("food")) {
      return "For your current goals of building muscle while staying lean, I recommend:\n\n**Daily Targets:**\n• Calories: 2,400 kcal\n• Protein: 165g (1g per lb bodyweight)\n• Carbs: 250g (fuel for workouts)\n• Fat: 70g (hormone health)\n\n**Pre-workout meal suggestion:**\nOatmeal with banana and protein powder, 60-90 min before training.\n\nWould you like specific meal suggestions?"
    }
    
    if (lowerMessage.includes("recovery") || lowerMessage.includes("sleep") || lowerMessage.includes("rest")) {
      return "Recovery is crucial for muscle growth and performance. Based on your activity data, here are my recommendations:\n\n**Sleep Optimization:**\n• Aim for 7-9 hours per night\n• Keep a consistent sleep schedule\n• Avoid screens 1 hour before bed\n\n**Active Recovery:**\n• Light stretching or yoga on rest days\n• 10-minute foam rolling post-workout\n• Stay hydrated (aim for 1 gallon daily)\n\nYour HRV indicates good recovery. Ready for tomorrow's pull day!"
    }
    
    if (lowerMessage.includes("progress") || lowerMessage.includes("analyze") || lowerMessage.includes("stats")) {
      return "Looking at your data from the past month:\n\n**Key Metrics:**\n• Weight: 185 → 178.5 lbs (-6.5 lbs)\n• Body Fat: 22% → 18.2% (-3.8%)\n• Bench Press: 185 → 225 lbs (+40 lbs)\n• Workout Consistency: 92%\n\n**Analysis:**\nExcellent progress! You're losing fat while gaining strength, indicating successful body recomposition. Your protein intake is on point. Consider increasing carbs slightly on training days for better energy.\n\nKeep up the great work! Want me to adjust your program?"
    }
    
    return "I understand you're looking for fitness guidance. I can help with:\n\n• **Workout Programming** - Custom plans based on your goals\n• **Nutrition Advice** - Macro calculations and meal suggestions\n• **Recovery Strategies** - Sleep, stretching, and active recovery\n• **Progress Analysis** - Insights from your tracking data\n\nWhat specific area would you like to focus on?"
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInput("")
    setIsTyping(true)

    // Simulate AI response delay
    setTimeout(() => {
      const response = generateResponse(input)
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: response,
        timestamp: new Date()
      }
      setMessages(prev => [...prev, assistantMessage])
      setIsTyping(false)
    }, 1000 + Math.random() * 1000)
  }

  const handleSuggestedPrompt = (text: string) => {
    setInput(text)
  }

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)]">
      {/* Chat Header */}
      <div className="flex items-center gap-3 p-4 border-b border-border/50">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center neon-glow">
          <Bot className="w-5 h-5 text-primary-foreground" />
        </div>
        <div>
          <h2 className="font-semibold">EvolveAI Coach</h2>
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            Always online
          </p>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex gap-3 ${message.role === "user" ? "flex-row-reverse" : ""}`}
          >
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
              message.role === "assistant" 
                ? "bg-gradient-to-br from-primary to-accent" 
                : "bg-secondary"
            }`}>
              {message.role === "assistant" ? (
                <Sparkles className="w-4 h-4 text-primary-foreground" />
              ) : (
                <User className="w-4 h-4" />
              )}
            </div>
            <div className={`max-w-[80%] ${message.role === "user" ? "text-right" : ""}`}>
              <div className={`inline-block p-4 rounded-2xl ${
                message.role === "assistant" 
                  ? "glass-card text-left" 
                  : "bg-primary text-primary-foreground"
              }`}>
                <p className="text-sm whitespace-pre-line">{message.content}</p>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-primary-foreground" />
            </div>
            <div className="glass-card rounded-2xl p-4">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                <span className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                <span className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompts */}
      {messages.length === 1 && (
        <div className="px-4 pb-4">
          <p className="text-xs text-muted-foreground mb-3">Quick actions</p>
          <div className="grid grid-cols-2 gap-3">
            {suggestedPrompts.map((prompt, index) => (
              <button
                key={index}
                onClick={() => handleSuggestedPrompt(prompt.text)}
                className="group flex items-center gap-3 p-4 text-left text-sm glass-card rounded-xl hover:neon-border hover:scale-[1.02] transition-all duration-200"
              >
                <div className="w-9 h-9 rounded-lg bg-primary/20 flex items-center justify-center group-hover:bg-primary/30 transition-colors">
                  <prompt.icon className="w-4 h-4 text-primary" />
                </div>
                <span className="text-muted-foreground line-clamp-2 group-hover:text-foreground transition-colors">{prompt.text}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <form onSubmit={handleSubmit} className="p-4 border-t border-border/50 glass">
        <div className="flex items-center gap-3">
          <div className="relative flex-1">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask your AI coach anything..."
              className="w-full bg-secondary/50 border border-border/50 rounded-xl px-4 py-3.5 text-sm focus:outline-none focus:border-primary/50 focus:ring-2 focus:ring-primary/20 transition-all placeholder:text-muted-foreground/60"
            />
            {input.trim() && (
              <div className="absolute right-3 top-1/2 -translate-y-1/2">
                <span className="text-xs text-muted-foreground">Press Enter</span>
              </div>
            )}
          </div>
          <Button 
            type="submit" 
            size="icon" 
            className="w-12 h-12 rounded-xl neon-glow bg-primary hover:bg-primary/90 hover:scale-105 transition-all disabled:opacity-50 disabled:hover:scale-100"
            disabled={!input.trim() || isTyping}
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>
      </form>
    </div>
  )
}
