"use client"

import { ChevronRight, Clock, Dumbbell, Flame, Play } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

const exercises = [
  { name: "Barbell Bench Press", sets: 4, reps: "8-10", rest: "90s", completed: true },
  { name: "Incline Dumbbell Press", sets: 3, reps: "10-12", rest: "60s", completed: true },
  { name: "Cable Flyes", sets: 3, reps: "12-15", rest: "45s", completed: false },
  { name: "Tricep Pushdowns", sets: 3, reps: "12-15", rest: "45s", completed: false },
  { name: "Overhead Tricep Extension", sets: 3, reps: "10-12", rest: "60s", completed: false },
]

export function TodaysWorkout() {
  const completedCount = exercises.filter(e => e.completed).length

  return (
    <div className="glass-card rounded-2xl p-6">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold">Today&apos;s Workout</h3>
          <p className="text-sm text-muted-foreground">Push Day - Chest & Triceps</p>
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Clock className="w-4 h-4" />
          <span>~45 min</span>
        </div>
      </div>

      {/* Progress */}
      <div className="mb-6">
        <div className="flex items-center justify-between text-sm mb-2">
          <span className="text-muted-foreground">Progress</span>
          <span className="font-medium">{completedCount}/{exercises.length} exercises</span>
        </div>
        <div className="h-2 bg-secondary rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-primary to-accent rounded-full transition-all duration-500"
            style={{ width: `${(completedCount / exercises.length) * 100}%` }}
          />
        </div>
      </div>

      {/* Exercise List */}
      <div className="space-y-3 mb-6">
        {exercises.map((exercise, index) => (
          <div
            key={index}
            className={`flex items-center justify-between p-3 rounded-xl transition-colors ${
              exercise.completed ? "bg-primary/10 border border-primary/20" : "bg-secondary/30"
            }`}
          >
            <div className="flex items-center gap-3">
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                exercise.completed ? "bg-primary/20" : "bg-secondary"
              }`}>
                <Dumbbell className={`w-4 h-4 ${exercise.completed ? "text-primary" : "text-muted-foreground"}`} />
              </div>
              <div>
                <p className={`text-sm font-medium ${exercise.completed ? "text-primary" : ""}`}>
                  {exercise.name}
                </p>
                <p className="text-xs text-muted-foreground">
                  {exercise.sets} sets × {exercise.reps} reps
                </p>
              </div>
            </div>
            {exercise.completed ? (
              <span className="text-xs text-primary font-medium">Done</span>
            ) : (
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            )}
          </div>
        ))}
      </div>

      {/* Stats */}
      <div className="flex items-center gap-4 p-4 bg-secondary/30 rounded-xl mb-6">
        <div className="flex items-center gap-2">
          <Flame className="w-4 h-4 text-primary" />
          <span className="text-sm text-muted-foreground">Est. Calories:</span>
          <span className="text-sm font-semibold">320</span>
        </div>
        <div className="w-px h-4 bg-border" />
        <div className="flex items-center gap-2">
          <Dumbbell className="w-4 h-4 text-accent" />
          <span className="text-sm text-muted-foreground">Volume:</span>
          <span className="text-sm font-semibold">12,450 lbs</span>
        </div>
      </div>

      {/* Action */}
      <Button className="w-full neon-glow bg-primary hover:bg-primary/90" asChild>
        <Link href="/dashboard/workouts">
          <Play className="w-4 h-4 mr-2" />
          Continue Workout
        </Link>
      </Button>
    </div>
  )
}
