"use client"

import { Activity, Flame, Scale, Target, TrendingDown, TrendingUp } from "lucide-react"
import { cn } from "@/lib/utils"

const stats = [
  {
    label: "Current Weight",
    value: "178.5",
    unit: "lbs",
    change: -2.3,
    changeLabel: "from last week",
    icon: Scale,
    positive: true
  },
  {
    label: "Body Fat",
    value: "18.2",
    unit: "%",
    change: -0.8,
    changeLabel: "from last month",
    icon: Target,
    positive: true
  },
  {
    label: "Calories Today",
    value: "1,847",
    unit: "kcal",
    change: 85,
    changeLabel: "% of goal",
    icon: Flame,
    positive: true
  },
  {
    label: "Active Minutes",
    value: "47",
    unit: "min",
    change: 12,
    changeLabel: "more than avg",
    icon: Activity,
    positive: true
  }
]

export function StatCards() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, index) => (
        <div
          key={index}
          className="group glass-card rounded-2xl p-5 hover:neon-border transition-all duration-300 hover:scale-[1.02]"
        >
          <div className="flex items-start justify-between mb-4">
            <div className="w-11 h-11 rounded-xl bg-primary/20 flex items-center justify-center group-hover:bg-primary/30 transition-colors">
              <stat.icon className="w-5 h-5 text-primary" />
            </div>
            <div className={cn(
              "flex items-center gap-1 text-xs px-2 py-1 rounded-full",
              stat.positive ? "text-emerald-400 bg-emerald-400/10" : "text-red-400 bg-red-400/10"
            )}>
              {stat.change < 0 ? (
                <TrendingDown className="w-3 h-3" />
              ) : (
                <TrendingUp className="w-3 h-3" />
              )}
              <span>{Math.abs(stat.change)}{stat.unit === "%" || stat.unit === "lbs" ? stat.unit : ""}</span>
            </div>
          </div>
          <div>
            <p className="text-3xl font-bold tracking-tight">
              {stat.value}
              <span className="text-sm font-normal text-muted-foreground ml-1">{stat.unit}</span>
            </p>
            <p className="text-sm text-muted-foreground mt-1.5">{stat.label}</p>
          </div>
        </div>
      ))}
    </div>
  )
}
