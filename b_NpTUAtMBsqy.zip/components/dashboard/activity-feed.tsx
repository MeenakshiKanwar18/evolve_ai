"use client"

import { Award, Dumbbell, Flame, Scale, TrendingUp } from "lucide-react"

const activities = [
  {
    icon: Dumbbell,
    title: "Completed Push Day",
    description: "Chest & Triceps workout finished",
    time: "2 hours ago",
    color: "primary"
  },
  {
    icon: Award,
    title: "New Personal Record!",
    description: "Bench Press: 225 lbs × 8 reps",
    time: "2 hours ago",
    color: "accent"
  },
  {
    icon: Flame,
    title: "Calorie Goal Reached",
    description: "Hit 2,200 kcal target for 5 days straight",
    time: "Yesterday",
    color: "chart-3"
  },
  {
    icon: Scale,
    title: "Weight Updated",
    description: "New weight: 178.5 lbs (-0.5 lbs)",
    time: "Yesterday",
    color: "primary"
  },
  {
    icon: TrendingUp,
    title: "Strength Milestone",
    description: "Increased overall strength by 5%",
    time: "3 days ago",
    color: "accent"
  }
]

export function ActivityFeed() {
  return (
    <div className="glass-card rounded-2xl p-6">
      <div className="mb-6">
        <h3 className="text-lg font-semibold">Recent Activity</h3>
        <p className="text-sm text-muted-foreground">Your latest achievements and updates</p>
      </div>

      <div className="space-y-4">
        {activities.map((activity, index) => (
          <div key={index} className="flex items-start gap-4">
            <div className={`w-10 h-10 rounded-xl bg-${activity.color}/20 flex items-center justify-center shrink-0`}>
              <activity.icon className={`w-5 h-5 text-${activity.color}`} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium">{activity.title}</p>
              <p className="text-xs text-muted-foreground">{activity.description}</p>
            </div>
            <span className="text-xs text-muted-foreground whitespace-nowrap">{activity.time}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
