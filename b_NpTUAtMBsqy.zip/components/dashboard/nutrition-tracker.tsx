"use client"

import { Plus } from "lucide-react"
import { Button } from "@/components/ui/button"

const macros = [
  { name: "Protein", current: 142, target: 165, unit: "g", color: "primary" },
  { name: "Carbs", current: 187, target: 220, unit: "g", color: "accent" },
  { name: "Fat", current: 58, target: 70, unit: "g", color: "chart-3" },
]

const recentMeals = [
  { name: "Breakfast", time: "7:30 AM", calories: 485, items: "Oatmeal, Eggs, Banana" },
  { name: "Snack", time: "10:00 AM", calories: 180, items: "Protein Shake" },
  { name: "Lunch", time: "12:30 PM", calories: 620, items: "Chicken Breast, Rice, Vegetables" },
  { name: "Snack", time: "3:30 PM", calories: 210, items: "Greek Yogurt, Almonds" },
]

export function NutritionTracker() {
  return (
    <div className="glass-card rounded-2xl p-6">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold">Nutrition Today</h3>
          <p className="text-sm text-muted-foreground">1,847 / 2,200 kcal</p>
        </div>
        <Button size="sm" variant="outline" className="glass-card border-border/50">
          <Plus className="w-4 h-4 mr-1" />
          Log Meal
        </Button>
      </div>

      {/* Calorie Ring */}
      <div className="flex items-center justify-center mb-6">
        <div className="relative w-32 h-32">
          <svg className="w-full h-full transform -rotate-90">
            <circle
              cx="64"
              cy="64"
              r="56"
              fill="none"
              stroke="rgba(139, 92, 246, 0.1)"
              strokeWidth="12"
            />
            <circle
              cx="64"
              cy="64"
              r="56"
              fill="none"
              stroke="url(#calorieGradient)"
              strokeWidth="12"
              strokeLinecap="round"
              strokeDasharray={`${(1847 / 2200) * 352} 352`}
              className="transition-all duration-1000"
            />
            <defs>
              <linearGradient id="calorieGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="hsl(270, 80%, 60%)" />
                <stop offset="100%" stopColor="hsl(280, 70%, 55%)" />
              </linearGradient>
            </defs>
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-2xl font-bold">84%</span>
            <span className="text-xs text-muted-foreground">of goal</span>
          </div>
        </div>
      </div>

      {/* Macros */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        {macros.map((macro) => (
          <div key={macro.name} className="text-center">
            <div className="h-2 bg-secondary rounded-full mb-2 overflow-hidden">
              <div 
                className={`h-full bg-${macro.color} rounded-full transition-all duration-500`}
                style={{ width: `${(macro.current / macro.target) * 100}%` }}
              />
            </div>
            <p className="text-xs text-muted-foreground">{macro.name}</p>
            <p className="text-sm font-semibold">
              {macro.current}<span className="text-muted-foreground font-normal">/{macro.target}{macro.unit}</span>
            </p>
          </div>
        ))}
      </div>

      {/* Recent Meals */}
      <div className="space-y-3">
        <p className="text-sm font-medium text-muted-foreground">Today&apos;s Meals</p>
        {recentMeals.map((meal, index) => (
          <div key={index} className="flex items-center justify-between p-3 bg-secondary/30 rounded-xl">
            <div>
              <p className="text-sm font-medium">{meal.name}</p>
              <p className="text-xs text-muted-foreground">{meal.items}</p>
            </div>
            <div className="text-right">
              <p className="text-sm font-semibold text-primary">{meal.calories}</p>
              <p className="text-xs text-muted-foreground">{meal.time}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
