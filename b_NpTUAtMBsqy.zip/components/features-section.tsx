"use client"

import { Activity, BarChart3, Bot, Calendar, Flame, Target, TrendingUp, Utensils } from "lucide-react"

const features = [
  {
    icon: Bot,
    title: "AI Coach Assistant",
    description: "24/7 intelligent guidance for workouts, nutrition, and recovery. Ask anything, get expert answers instantly.",
    gradient: "from-primary to-accent"
  },
  {
    icon: Target,
    title: "Goal-Based Programming",
    description: "Whether you want to build muscle, lose fat, or improve endurance, our AI creates the perfect plan for you.",
    gradient: "from-accent to-primary"
  },
  {
    icon: Calendar,
    title: "Adaptive Scheduling",
    description: "Smart workout scheduling that adapts to your life. Missed a session? AI automatically readjusts your program.",
    gradient: "from-primary to-accent"
  },
  {
    icon: Utensils,
    title: "Nutrition Intelligence",
    description: "Personalized meal plans and macro tracking based on your goals, preferences, and dietary restrictions.",
    gradient: "from-accent to-primary"
  },
  {
    icon: TrendingUp,
    title: "Progress Prediction",
    description: "Machine learning models predict your future progress and optimize training for maximum results.",
    gradient: "from-primary to-accent"
  },
  {
    icon: Activity,
    title: "Biometric Integration",
    description: "Connect wearables for heart rate, sleep, and recovery data. AI uses this for smarter recommendations.",
    gradient: "from-accent to-primary"
  },
  {
    icon: Flame,
    title: "Calorie Intelligence",
    description: "Accurate calorie and macro tracking with AI-powered food recognition. Just snap a photo of your meal.",
    gradient: "from-primary to-accent"
  },
  {
    icon: BarChart3,
    title: "Advanced Analytics",
    description: "Beautiful visualizations of your progress across every metric. See trends, patterns, and insights.",
    gradient: "from-accent to-primary"
  }
]

export function FeaturesSection() {
  return (
    <section className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 gradient-mesh opacity-50" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold">
            Everything You Need to{" "}
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Transform
            </span>
          </h2>
          <p className="max-w-2xl mx-auto text-lg text-muted-foreground">
            A complete AI-powered ecosystem designed to optimize every aspect of your fitness journey.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group relative glass-card rounded-2xl p-6 hover:neon-border transition-all duration-300 hover:scale-[1.02] hover:-translate-y-1"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              {/* Gradient background on hover */}
              <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-300`} />
              
              <div className="relative">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  <feature.icon className="w-6 h-6 text-primary-foreground" />
                </div>
                <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors">{feature.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
