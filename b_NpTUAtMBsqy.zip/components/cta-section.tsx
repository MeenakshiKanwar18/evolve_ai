"use client"

import Link from "next/link"
import { ArrowRight, CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"

const benefits = [
  "Personalized AI workout plans",
  "Custom nutrition guidance",
  "Real-time progress tracking",
  "24/7 AI coach support",
  "Cancel anytime"
]

export function CTASection() {
  return (
    <section className="relative py-32 overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/5 to-background" />
      <div className="absolute inset-0 grid-pattern opacity-30" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/10 rounded-full blur-3xl" />
      
      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="glass-card rounded-3xl p-10 sm:p-14 neon-border hover:scale-[1.01] transition-transform duration-500">
          {/* Header */}
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6 text-balance">
            Ready to{" "}
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent neon-text">
              Transform
            </span>
            {" "}Your Body?
          </h2>
          <p className="text-lg text-muted-foreground mb-10 max-w-xl mx-auto text-balance leading-relaxed">
            Join 50,000+ people who have revolutionized their fitness journey with AI-powered training and nutrition.
          </p>

          {/* Benefits */}
          <div className="flex flex-wrap justify-center gap-x-6 gap-y-3 mb-10">
            {benefits.map((benefit, index) => (
              <div key={index} className="flex items-center gap-2 text-sm group">
                <CheckCircle2 className="w-5 h-5 text-primary group-hover:scale-110 transition-transform" />
                <span className="text-muted-foreground group-hover:text-foreground transition-colors">{benefit}</span>
              </div>
            ))}
          </div>

          {/* CTA Button */}
          <Button size="lg" className="neon-glow bg-primary hover:bg-primary/90 text-lg px-12 h-14 group" asChild>
            <Link href="/dashboard">
              Start Your Free Trial
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </Button>

          <p className="text-sm text-muted-foreground mt-6">
            No credit card required. 14-day free trial. Cancel anytime.
          </p>
        </div>
      </div>
    </section>
  )
}
