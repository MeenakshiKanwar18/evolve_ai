"use client"

import { useState } from "react"
import { Bell, ChevronRight, CreditCard, Globe, Lock, Moon, Palette, Shield, Smartphone, User, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"

const settingsSections = [
  {
    title: "Account",
    items: [
      { label: "Profile Information", description: "Update your personal details", icon: User, href: "#" },
      { label: "Password & Security", description: "Manage password and 2FA", icon: Lock, href: "#" },
      { label: "Privacy Settings", description: "Control your data visibility", icon: Shield, href: "#" },
    ]
  },
  {
    title: "Preferences",
    items: [
      { label: "Notifications", description: "Configure push and email alerts", icon: Bell, href: "#" },
      { label: "Appearance", description: "Theme and display settings", icon: Palette, href: "#" },
      { label: "Language & Region", description: "Set language and units", icon: Globe, href: "#" },
    ]
  },
  {
    title: "Connected Apps",
    items: [
      { label: "Wearable Devices", description: "Connect fitness trackers", icon: Smartphone, href: "#" },
      { label: "Third-party Apps", description: "Manage app integrations", icon: Zap, href: "#" },
    ]
  },
  {
    title: "Subscription",
    items: [
      { label: "Billing & Plans", description: "Manage your subscription", icon: CreditCard, href: "#" },
    ]
  },
]

const toggleSettings = [
  { label: "Dark Mode", description: "Use dark theme across the app", enabled: true },
  { label: "Push Notifications", description: "Receive workout reminders", enabled: true },
  { label: "Email Notifications", description: "Weekly progress reports", enabled: false },
  { label: "Sound Effects", description: "Play sounds during workouts", enabled: true },
  { label: "Auto-sync Data", description: "Sync with connected devices", enabled: true },
]

export default function SettingsPage() {
  const [toggleStates, setToggleStates] = useState(
    toggleSettings.reduce((acc, setting, index) => ({ ...acc, [index]: setting.enabled }), {} as Record<number, boolean>)
  )

  const handleToggle = (index: number) => {
    setToggleStates(prev => ({ ...prev, [index]: !prev[index] }))
  }

  return (
    <div className="p-6 lg:p-8 max-w-4xl">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-2xl lg:text-3xl font-bold">Settings</h1>
        <p className="text-muted-foreground">Manage your account and preferences</p>
      </div>

      {/* Profile Card */}
      <div className="glass-card rounded-2xl p-6 mb-8">
        <div className="flex items-center gap-4">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center text-3xl font-bold">
            MK
          </div>
          <div className="flex-1">
            <h2 className="text-xl font-semibold">Meenakshi Kanwar</h2>
            <p className="text-muted-foreground">meenakshi.kanwar@email.com</p>
            <div className="flex items-center gap-2 mt-2">
              <span className="px-2 py-0.5 text-xs bg-primary/20 text-primary rounded-full">Pro Member</span>
              <span className="text-xs text-muted-foreground">Member since Jan 2026</span>
            </div>
          </div>
          <Button variant="outline" className="glass-card border-border/50">
            Edit Profile
          </Button>
        </div>
      </div>

      {/* Settings Sections */}
      <div className="space-y-6">
        {settingsSections.map((section, sectionIndex) => (
          <div key={sectionIndex} className="glass-card rounded-2xl overflow-hidden">
            <div className="px-6 py-4 border-b border-border/50">
              <h3 className="font-semibold">{section.title}</h3>
            </div>
            <div>
              {section.items.map((item, itemIndex) => (
                <button
                  key={itemIndex}
                  className="w-full flex items-center justify-between p-4 hover:bg-secondary/30 transition-colors border-b border-border/30 last:border-0"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
                      <item.icon className="w-5 h-5 text-primary" />
                    </div>
                    <div className="text-left">
                      <p className="font-medium">{item.label}</p>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground" />
                </button>
              ))}
            </div>
          </div>
        ))}

        {/* Toggle Settings */}
        <div className="glass-card rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-border/50">
            <h3 className="font-semibold">Quick Settings</h3>
          </div>
          <div className="p-2">
            {toggleSettings.map((setting, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-4 rounded-xl hover:bg-secondary/30 transition-colors"
              >
                <div>
                  <p className="font-medium">{setting.label}</p>
                  <p className="text-sm text-muted-foreground">{setting.description}</p>
                </div>
                <button
                  onClick={() => handleToggle(index)}
                  className={`relative w-12 h-7 rounded-full transition-colors ${
                    toggleStates[index] ? "bg-primary" : "bg-secondary"
                  }`}
                >
                  <div
                    className={`absolute top-1 w-5 h-5 rounded-full bg-white transition-transform ${
                      toggleStates[index] ? "translate-x-6" : "translate-x-1"
                    }`}
                  />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Danger Zone */}
        <div className="glass-card rounded-2xl overflow-hidden border border-destructive/20">
          <div className="px-6 py-4 border-b border-border/50">
            <h3 className="font-semibold text-destructive">Danger Zone</h3>
          </div>
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between p-4 bg-destructive/5 rounded-xl">
              <div>
                <p className="font-medium">Export Data</p>
                <p className="text-sm text-muted-foreground">Download all your fitness data</p>
              </div>
              <Button variant="outline" size="sm">
                Export
              </Button>
            </div>
            <div className="flex items-center justify-between p-4 bg-destructive/5 rounded-xl">
              <div>
                <p className="font-medium text-destructive">Delete Account</p>
                <p className="text-sm text-muted-foreground">Permanently delete your account and data</p>
              </div>
              <Button variant="destructive" size="sm">
                Delete
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* App Info */}
      <div className="mt-8 text-center text-sm text-muted-foreground">
        <p>EvolveAI v2.0.0</p>
        <p className="mt-1">Made with AI-powered intelligence</p>
      </div>
    </div>
  )
}
