import { StatCards } from "@/components/dashboard/stat-cards"
import { ProgressChart } from "@/components/dashboard/progress-chart"
import { TodaysWorkout } from "@/components/dashboard/todays-workout"
import { NutritionTracker } from "@/components/dashboard/nutrition-tracker"
import { ActivityFeed } from "@/components/dashboard/activity-feed"
import { Bell, Search, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function DashboardPage() {
  const currentHour = new Date().getHours()
  const greeting = currentHour < 12 ? "Good morning" : currentHour < 18 ? "Good afternoon" : "Good evening"

  return (
    <div className="p-6 lg:p-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-2xl lg:text-3xl font-bold">{greeting}, Meenakshi</h1>
            <Sparkles className="w-5 h-5 text-primary animate-pulse" />
          </div>
          <p className="text-muted-foreground">Here&apos;s your fitness overview for today</p>
        </div>
        <div className="flex items-center gap-3">
          <Button size="icon" variant="ghost" className="glass-card border border-border/50 hover:border-primary/50 hover:bg-primary/5 transition-all">
            <Search className="w-4 h-4" />
          </Button>
          <Button size="icon" variant="ghost" className="glass-card border border-border/50 hover:border-primary/50 hover:bg-primary/5 transition-all relative">
            <Bell className="w-4 h-4" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-primary rounded-full animate-pulse" />
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="mb-8">
        <StatCards />
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Chart */}
        <div className="lg:col-span-2">
          <ProgressChart />
        </div>

        {/* Right Column - Activity */}
        <div>
          <ActivityFeed />
        </div>
      </div>

      {/* Bottom Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
        <TodaysWorkout />
        <NutritionTracker />
      </div>
    </div>
  )
}
