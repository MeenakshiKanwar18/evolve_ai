"use client"

import { Activity, Award, Calendar, Clock, Dumbbell, Flame, Heart, Moon, Scale, TrendingUp, Zap } from "lucide-react"

const todayStats = {
  steps: 8432,
  stepsGoal: 10000,
  calories: 487,
  caloriesGoal: 600,
  activeMinutes: 47,
  activeGoal: 60,
  heartRate: 68,
  sleep: 7.2,
}

const weeklyActivity = [
  { day: "Mon", steps: 9234, calories: 520, active: 55 },
  { day: "Tue", steps: 11205, calories: 680, active: 72 },
  { day: "Wed", steps: 7823, calories: 445, active: 38 },
  { day: "Thu", steps: 10456, calories: 590, active: 62 },
  { day: "Fri", steps: 8432, calories: 487, active: 47 },
  { day: "Sat", steps: 0, calories: 0, active: 0 },
  { day: "Sun", steps: 0, calories: 0, active: 0 },
]

const recentActivity = [
  {
    type: "workout",
    title: "Push Day Completed",
    subtitle: "Chest & Triceps",
    time: "2h ago",
    stats: "45 min • 320 kcal",
    icon: Dumbbell,
    color: "primary"
  },
  {
    type: "achievement",
    title: "New Personal Record",
    subtitle: "Bench Press: 225 lbs × 8",
    time: "2h ago",
    stats: "+15 lbs from last week",
    icon: Award,
    color: "accent"
  },
  {
    type: "weight",
    title: "Weight Updated",
    subtitle: "178.5 lbs recorded",
    time: "6h ago",
    stats: "-0.5 lbs from yesterday",
    icon: Scale,
    color: "chart-3"
  },
  {
    type: "nutrition",
    title: "Calorie Goal Reached",
    subtitle: "2,200 kcal consumed",
    time: "Yesterday",
    stats: "5 day streak!",
    icon: Flame,
    color: "chart-4"
  },
  {
    type: "sleep",
    title: "Sleep Logged",
    subtitle: "7.5 hours of sleep",
    time: "Yesterday",
    stats: "Good recovery",
    icon: Moon,
    color: "primary"
  },
  {
    type: "workout",
    title: "Pull Day Completed",
    subtitle: "Back & Biceps",
    time: "2 days ago",
    stats: "52 min • 380 kcal",
    icon: Dumbbell,
    color: "primary"
  },
]

const healthMetrics = [
  { label: "Resting HR", value: "62", unit: "bpm", trend: "normal", icon: Heart },
  { label: "HRV", value: "48", unit: "ms", trend: "good", icon: Activity },
  { label: "Sleep Score", value: "85", unit: "/100", trend: "excellent", icon: Moon },
  { label: "Recovery", value: "92", unit: "%", trend: "excellent", icon: Zap },
]

export default function ActivityPage() {
  return (
    <div className="p-6 lg:p-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold">Activity</h1>
          <p className="text-muted-foreground">Track your daily movement and health metrics</p>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Calendar className="w-4 h-4" />
          <span>{new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}</span>
        </div>
      </div>

      {/* Today's Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {[
          { label: "Steps", value: todayStats.steps.toLocaleString(), goal: todayStats.stepsGoal.toLocaleString(), icon: Activity, color: "primary" },
          { label: "Calories Burned", value: todayStats.calories.toString(), goal: todayStats.caloriesGoal.toString(), unit: "kcal", icon: Flame, color: "accent" },
          { label: "Active Minutes", value: todayStats.activeMinutes.toString(), goal: todayStats.activeGoal.toString(), unit: "min", icon: Clock, color: "chart-3" },
          { label: "Resting HR", value: todayStats.heartRate.toString(), unit: "bpm", icon: Heart, color: "chart-4" },
        ].map((stat, index) => {
          const percentage = stat.goal ? (parseInt(stat.value.replace(',', '')) / parseInt(stat.goal.replace(',', ''))) * 100 : null
          return (
            <div key={index} className="glass-card rounded-2xl p-5 hover:neon-border transition-all">
              <div className="flex items-start justify-between mb-3">
                <div className={`w-10 h-10 rounded-xl bg-${stat.color}/20 flex items-center justify-center`}>
                  <stat.icon className={`w-5 h-5 text-${stat.color}`} />
                </div>
                {percentage !== null && (
                  <span className="text-xs text-muted-foreground">{Math.round(percentage)}%</span>
                )}
              </div>
              <p className="text-2xl font-bold">
                {stat.value}
                {stat.unit && <span className="text-sm font-normal text-muted-foreground ml-1">{stat.unit}</span>}
              </p>
              <p className="text-sm text-muted-foreground">
                {stat.label}
                {stat.goal && <span className="text-xs"> / {stat.goal}</span>}
              </p>
              {percentage !== null && (
                <div className="h-1.5 bg-secondary rounded-full mt-3 overflow-hidden">
                  <div 
                    className={`h-full bg-${stat.color} rounded-full`}
                    style={{ width: `${Math.min(percentage, 100)}%` }}
                  />
                </div>
              )}
            </div>
          )
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Weekly Overview */}
        <div className="lg:col-span-2 glass-card rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold">Weekly Overview</h3>
              <p className="text-sm text-muted-foreground">Your activity this week</p>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-primary" />
                <span className="text-muted-foreground">Steps</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-accent" />
                <span className="text-muted-foreground">Calories</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-7 gap-2">
            {weeklyActivity.map((day, index) => {
              const stepsHeight = day.steps > 0 ? (day.steps / 12000) * 100 : 5
              const caloriesHeight = day.calories > 0 ? (day.calories / 700) * 100 : 5
              const isToday = index === 4
              
              return (
                <div key={day.day} className="text-center">
                  <div className="h-32 flex items-end justify-center gap-1 mb-2">
                    <div 
                      className={`w-3 rounded-t-sm ${isToday ? "bg-primary" : "bg-primary/50"}`}
                      style={{ height: `${stepsHeight}%` }}
                    />
                    <div 
                      className={`w-3 rounded-t-sm ${isToday ? "bg-accent" : "bg-accent/50"}`}
                      style={{ height: `${caloriesHeight}%` }}
                    />
                  </div>
                  <p className={`text-xs ${isToday ? "text-primary font-medium" : "text-muted-foreground"}`}>
                    {day.day}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {day.steps > 0 ? `${(day.steps / 1000).toFixed(1)}k` : "-"}
                  </p>
                </div>
              )
            })}
          </div>

          {/* Summary */}
          <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t border-border/50">
            <div className="text-center">
              <p className="text-2xl font-bold text-primary">47,150</p>
              <p className="text-xs text-muted-foreground">Total Steps</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-accent">2,722</p>
              <p className="text-xs text-muted-foreground">Calories Burned</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold">4h 34m</p>
              <p className="text-xs text-muted-foreground">Active Time</p>
            </div>
          </div>
        </div>

        {/* Health Metrics */}
        <div className="glass-card rounded-2xl p-6">
          <div className="flex items-center gap-2 mb-6">
            <Heart className="w-5 h-5 text-primary" />
            <h3 className="font-semibold">Health Metrics</h3>
          </div>

          <div className="space-y-4">
            {healthMetrics.map((metric, index) => (
              <div key={index} className="p-4 bg-secondary/30 rounded-xl">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <metric.icon className="w-4 h-4 text-primary" />
                    <span className="text-sm">{metric.label}</span>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                    metric.trend === "excellent" ? "bg-green-500/20 text-green-400" :
                    metric.trend === "good" ? "bg-primary/20 text-primary" :
                    "bg-secondary text-muted-foreground"
                  }`}>
                    {metric.trend}
                  </span>
                </div>
                <p className="text-2xl font-bold">
                  {metric.value}
                  <span className="text-sm font-normal text-muted-foreground ml-1">{metric.unit}</span>
                </p>
              </div>
            ))}
          </div>

          <div className="mt-4 p-4 bg-green-500/10 border border-green-500/20 rounded-xl">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-4 h-4 text-green-400" />
              <p className="text-sm font-medium text-green-400">Great Recovery</p>
            </div>
            <p className="text-xs text-muted-foreground">Your body is well-recovered. Perfect day for an intense workout!</p>
          </div>
        </div>
      </div>

      {/* Recent Activity Feed */}
      <div className="mt-6 glass-card rounded-2xl p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold">Recent Activity</h3>
          <span className="text-sm text-muted-foreground">Last 7 days</span>
        </div>

        <div className="space-y-4">
          {recentActivity.map((activity, index) => (
            <div key={index} className="flex items-start gap-4 p-4 bg-secondary/20 rounded-xl hover:bg-secondary/30 transition-colors">
              <div className={`w-12 h-12 rounded-xl bg-${activity.color}/20 flex items-center justify-center shrink-0`}>
                <activity.icon className={`w-6 h-6 text-${activity.color}`} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="font-medium">{activity.title}</p>
                    <p className="text-sm text-muted-foreground">{activity.subtitle}</p>
                  </div>
                  <span className="text-xs text-muted-foreground whitespace-nowrap">{activity.time}</span>
                </div>
                <p className="text-xs text-primary mt-1">{activity.stats}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
