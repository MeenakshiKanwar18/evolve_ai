"use client"

import { useState } from "react"
import { 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  RadialBarChart,
  RadialBar
} from "recharts"
import { 
  Activity, 
  Award, 
  Calendar, 
  Dumbbell, 
  Flame, 
  Scale, 
  Sparkles, 
  Target, 
  TrendingDown, 
  TrendingUp,
  Zap
} from "lucide-react"
import { Button } from "@/components/ui/button"

const weightData = [
  { date: "Week 1", weight: 185, bodyFat: 22 },
  { date: "Week 2", weight: 184, bodyFat: 21.5 },
  { date: "Week 3", weight: 183, bodyFat: 21 },
  { date: "Week 4", weight: 182, bodyFat: 20.5 },
  { date: "Week 5", weight: 181, bodyFat: 20 },
  { date: "Week 6", weight: 180, bodyFat: 19.5 },
  { date: "Week 7", weight: 179, bodyFat: 19 },
  { date: "Week 8", weight: 178.5, bodyFat: 18.2 },
]

const strengthData = [
  { exercise: "Bench", current: 225, previous: 185, max: 250 },
  { exercise: "Squat", current: 275, previous: 235, max: 315 },
  { exercise: "Deadlift", current: 315, previous: 275, max: 365 },
  { exercise: "OHP", current: 135, previous: 115, max: 155 },
]

const workoutConsistency = [
  { day: "Mon", workouts: 4, target: 4 },
  { day: "Tue", workouts: 4, target: 4 },
  { day: "Wed", workouts: 3, target: 4 },
  { day: "Thu", workouts: 4, target: 4 },
  { day: "Fri", workouts: 4, target: 4 },
  { day: "Sat", workouts: 3, target: 4 },
  { day: "Sun", workouts: 2, target: 4 },
]

const muscleGroupProgress = [
  { name: "Chest", value: 85, fill: "hsl(270, 80%, 60%)" },
  { name: "Back", value: 78, fill: "hsl(280, 70%, 55%)" },
  { name: "Shoulders", value: 72, fill: "hsl(290, 65%, 50%)" },
  { name: "Arms", value: 80, fill: "hsl(260, 75%, 58%)" },
  { name: "Legs", value: 65, fill: "hsl(300, 60%, 48%)" },
]

const calorieHistory = [
  { date: "Mon", consumed: 2350, burned: 2400, target: 2400 },
  { date: "Tue", consumed: 2200, burned: 2500, target: 2400 },
  { date: "Wed", consumed: 2450, burned: 2300, target: 2400 },
  { date: "Thu", consumed: 2100, burned: 2200, target: 2400 },
  { date: "Fri", consumed: 2380, burned: 2600, target: 2400 },
  { date: "Sat", consumed: 2500, burned: 2100, target: 2400 },
  { date: "Sun", consumed: 1847, burned: 2000, target: 2400 },
]

const achievements = [
  { title: "8 Week Streak", description: "Completed 8 consecutive weeks of training", icon: Flame, color: "primary" },
  { title: "100 Workouts", description: "Logged your 100th workout session", icon: Dumbbell, color: "accent" },
  { title: "Body Recomp", description: "Lost 6.5 lbs while gaining strength", icon: Target, color: "chart-3" },
  { title: "PR Hunter", description: "Set 12 personal records this month", icon: Award, color: "chart-4" },
]

interface CustomTooltipProps {
  active?: boolean
  payload?: Array<{ value: number; dataKey: string; color?: string; name?: string }>
  label?: string
}

function CustomTooltip({ active, payload, label }: CustomTooltipProps) {
  if (active && payload && payload.length) {
    return (
      <div className="glass-card rounded-lg p-3 border border-border/50">
        <p className="text-sm font-medium mb-2">{label}</p>
        {payload.map((entry, index) => (
          <div key={index} className="flex items-center gap-2 text-xs">
            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
            <span className="text-muted-foreground capitalize">{entry.name || entry.dataKey}:</span>
            <span className="font-medium">{entry.value}</span>
          </div>
        ))}
      </div>
    )
  }
  return null
}

export default function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState("8w")

  return (
    <div className="p-6 lg:p-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold">Analytics</h1>
          <p className="text-muted-foreground">Deep insights into your fitness journey</p>
        </div>
        <div className="flex items-center gap-2">
          {["1w", "4w", "8w", "12w", "1y"].map((range) => (
            <Button
              key={range}
              variant={timeRange === range ? "default" : "ghost"}
              size="sm"
              onClick={() => setTimeRange(range)}
              className={timeRange === range ? "neon-glow bg-primary" : ""}
            >
              {range}
            </Button>
          ))}
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {[
          { label: "Weight Lost", value: "6.5", unit: "lbs", change: -3.5, icon: Scale, color: "primary" },
          { label: "Body Fat Lost", value: "3.8", unit: "%", change: -17, icon: Target, color: "accent" },
          { label: "Strength Gain", value: "21", unit: "%", change: 21, icon: Dumbbell, color: "chart-3" },
          { label: "Workouts", value: "32", unit: "sessions", change: 14, icon: Activity, color: "chart-4" },
        ].map((stat, index) => (
          <div key={index} className="glass-card rounded-2xl p-5 hover:neon-border transition-all">
            <div className="flex items-start justify-between mb-3">
              <div className={`w-10 h-10 rounded-xl bg-${stat.color}/20 flex items-center justify-center`}>
                <stat.icon className={`w-5 h-5 text-${stat.color}`} />
              </div>
              <div className={`flex items-center gap-1 text-xs ${stat.change < 0 ? "text-green-400" : "text-green-400"}`}>
                {stat.change < 0 ? <TrendingDown className="w-3 h-3" /> : <TrendingUp className="w-3 h-3" />}
                <span>{Math.abs(stat.change)}%</span>
              </div>
            </div>
            <p className="text-2xl font-bold">
              {stat.value}
              <span className="text-sm font-normal text-muted-foreground ml-1">{stat.unit}</span>
            </p>
            <p className="text-sm text-muted-foreground">{stat.label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Weight & Body Fat Chart */}
        <div className="glass-card rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold">Weight & Body Composition</h3>
              <p className="text-sm text-muted-foreground">Track your transformation</p>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-primary" />
                <span className="text-muted-foreground">Weight</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-accent" />
                <span className="text-muted-foreground">Body Fat %</span>
              </div>
            </div>
          </div>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={weightData}>
                <defs>
                  <linearGradient id="weightGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(270, 80%, 60%)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(270, 80%, 60%)" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="bodyFatGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(280, 70%, 55%)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(280, 70%, 55%)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(139, 92, 246, 0.1)" />
                <XAxis dataKey="date" stroke="rgba(255,255,255,0.4)" fontSize={11} tickLine={false} axisLine={false} />
                <YAxis stroke="rgba(255,255,255,0.4)" fontSize={11} tickLine={false} axisLine={false} domain={['auto', 'auto']} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="weight" stroke="hsl(270, 80%, 60%)" strokeWidth={2} fill="url(#weightGrad)" />
                <Area type="monotone" dataKey="bodyFat" stroke="hsl(280, 70%, 55%)" strokeWidth={2} fill="url(#bodyFatGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Strength Progress */}
        <div className="glass-card rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold">Strength Progress</h3>
              <p className="text-sm text-muted-foreground">1RM estimates over time</p>
            </div>
          </div>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={strengthData} barGap={8}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(139, 92, 246, 0.1)" />
                <XAxis dataKey="exercise" stroke="rgba(255,255,255,0.4)" fontSize={11} tickLine={false} axisLine={false} />
                <YAxis stroke="rgba(255,255,255,0.4)" fontSize={11} tickLine={false} axisLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="previous" fill="rgba(139, 92, 246, 0.3)" radius={[4, 4, 0, 0]} name="8 Weeks Ago" />
                <Bar dataKey="current" fill="hsl(270, 80%, 60%)" radius={[4, 4, 0, 0]} name="Current" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Workout Consistency */}
        <div className="glass-card rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold">Weekly Consistency</h3>
              <p className="text-sm text-muted-foreground">Last 4 weeks average</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-primary">92%</p>
              <p className="text-xs text-muted-foreground">adherence</p>
            </div>
          </div>
          <div className="h-[180px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={workoutConsistency}>
                <XAxis dataKey="day" stroke="rgba(255,255,255,0.4)" fontSize={11} tickLine={false} axisLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="workouts" fill="hsl(270, 80%, 60%)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Muscle Group Progress */}
        <div className="glass-card rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold">Muscle Development</h3>
              <p className="text-sm text-muted-foreground">Progress by muscle group</p>
            </div>
          </div>
          <div className="h-[180px]">
            <ResponsiveContainer width="100%" height="100%">
              <RadialBarChart cx="50%" cy="50%" innerRadius="20%" outerRadius="90%" data={muscleGroupProgress} startAngle={90} endAngle={-270}>
                <RadialBar dataKey="value" cornerRadius={4} />
                <Tooltip content={<CustomTooltip />} />
              </RadialBarChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap justify-center gap-3 mt-2">
            {muscleGroupProgress.map((muscle) => (
              <div key={muscle.name} className="flex items-center gap-1 text-xs">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: muscle.fill }} />
                <span className="text-muted-foreground">{muscle.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Calorie Balance */}
        <div className="glass-card rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold">Calorie Balance</h3>
              <p className="text-sm text-muted-foreground">This week&apos;s nutrition</p>
            </div>
          </div>
          <div className="h-[180px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={calorieHistory}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(139, 92, 246, 0.1)" />
                <XAxis dataKey="date" stroke="rgba(255,255,255,0.4)" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis stroke="rgba(255,255,255,0.4)" fontSize={10} tickLine={false} axisLine={false} domain={[1800, 2800]} />
                <Tooltip content={<CustomTooltip />} />
                <Line type="monotone" dataKey="consumed" stroke="hsl(270, 80%, 60%)" strokeWidth={2} dot={false} name="Consumed" />
                <Line type="monotone" dataKey="burned" stroke="hsl(280, 70%, 55%)" strokeWidth={2} dot={false} name="Burned" />
                <Line type="monotone" dataKey="target" stroke="rgba(255,255,255,0.2)" strokeWidth={1} strokeDasharray="5 5" dot={false} name="Target" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Bottom Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* AI Insights */}
        <div className="glass-card rounded-2xl p-6 neon-border">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">AI Analysis</h3>
              <p className="text-sm text-muted-foreground">Insights from your data</p>
            </div>
          </div>
          <div className="space-y-4">
            <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-green-400" />
                <p className="font-medium text-green-400">Excellent Progress</p>
              </div>
              <p className="text-sm text-muted-foreground">You&apos;ve achieved body recomposition - losing fat while gaining muscle. This is optimal for your goals.</p>
            </div>
            <div className="p-4 bg-primary/10 border border-primary/20 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="w-4 h-4 text-primary" />
                <p className="font-medium text-primary">Optimization Tip</p>
              </div>
              <p className="text-sm text-muted-foreground">Your leg training volume is lower than other muscle groups. Consider adding an extra leg day for balanced development.</p>
            </div>
            <div className="p-4 bg-accent/10 border border-accent/20 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <Target className="w-4 h-4 text-accent" />
                <p className="font-medium text-accent">Projection</p>
              </div>
              <p className="text-sm text-muted-foreground">At your current rate, you&apos;ll reach 175 lbs at 15% body fat in approximately 6 weeks.</p>
            </div>
          </div>
        </div>

        {/* Achievements */}
        <div className="glass-card rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Award className="w-6 h-6 text-primary" />
              <div>
                <h3 className="text-lg font-semibold">Achievements</h3>
                <p className="text-sm text-muted-foreground">Your fitness milestones</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" className="text-muted-foreground">
              View All
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {achievements.map((achievement, index) => (
              <div key={index} className="p-4 bg-secondary/30 rounded-xl hover:bg-secondary/50 transition-colors cursor-pointer group">
                <div className={`w-12 h-12 rounded-xl bg-${achievement.color}/20 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                  <achievement.icon className={`w-6 h-6 text-${achievement.color}`} />
                </div>
                <p className="font-medium text-sm">{achievement.title}</p>
                <p className="text-xs text-muted-foreground mt-1">{achievement.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
