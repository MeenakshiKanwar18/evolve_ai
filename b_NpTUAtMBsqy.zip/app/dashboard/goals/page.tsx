"use client"

import { useState } from "react"
import { Calendar, Check, ChevronRight, Edit3, Flag, Plus, Sparkles, Target, TrendingUp, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"

const userProfile = {
  height: "5'10\"",
  weight: "178.5 lbs",
  age: 28,
  gender: "Male",
  activityLevel: "Very Active",
  goal: "Body Recomposition",
}

const mainGoals = [
  {
    id: 1,
    title: "Reach 175 lbs",
    description: "Target weight while maintaining muscle mass",
    current: 178.5,
    target: 175,
    unit: "lbs",
    deadline: "Aug 15, 2026",
    progress: 65,
    color: "primary"
  },
  {
    id: 2,
    title: "15% Body Fat",
    description: "Achieve lean physique for summer",
    current: 18.2,
    target: 15,
    unit: "%",
    deadline: "Sep 1, 2026",
    progress: 47,
    color: "accent"
  },
  {
    id: 3,
    title: "225 lbs Bench Press",
    description: "Hit two plates for reps",
    current: 225,
    target: 225,
    unit: "lbs",
    deadline: "Achieved!",
    progress: 100,
    color: "chart-3"
  },
  {
    id: 4,
    title: "300 lbs Squat",
    description: "Build stronger legs",
    current: 275,
    target: 300,
    unit: "lbs",
    deadline: "Jul 1, 2026",
    progress: 92,
    color: "chart-4"
  },
]

const weeklyGoals = [
  { task: "Complete 5 workouts", completed: 4, target: 5, done: false },
  { task: "Hit protein goal daily", completed: 6, target: 7, done: false },
  { task: "Sleep 7+ hours", completed: 5, target: 7, done: false },
  { task: "10,000 steps per day", completed: 7, target: 7, done: true },
  { task: "Drink 1 gallon water", completed: 6, target: 7, done: false },
]

const aiRecommendations = [
  {
    title: "Adjust Calorie Deficit",
    description: "Based on your progress, increase daily calories by 100 to preserve muscle while cutting.",
    priority: "high"
  },
  {
    title: "Add Leg Volume",
    description: "Your lower body development is lagging. Add 2 extra sets of squats per week.",
    priority: "medium"
  },
  {
    title: "Recovery Focus",
    description: "Your sleep average is 6.2 hours. Aim for 7-8 hours for optimal gains.",
    priority: "high"
  },
]

export default function GoalsPage() {
  const [editingProfile, setEditingProfile] = useState(false)

  return (
    <div className="p-6 lg:p-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold">Goals & Profile</h1>
          <p className="text-muted-foreground">Set targets and track your fitness journey</p>
        </div>
        <Button className="neon-glow bg-primary hover:bg-primary/90">
          <Plus className="w-4 h-4 mr-2" />
          New Goal
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* User Profile Card */}
          <div className="glass-card rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center text-2xl font-bold">
                  MK
                </div>
                <div>
                  <h2 className="text-xl font-semibold">Meenakshi Kanwar</h2>
                  <p className="text-sm text-muted-foreground">Pro Member • Member since Jan 2026</p>
                </div>
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                className="glass-card border-border/50"
                onClick={() => setEditingProfile(!editingProfile)}
              >
                <Edit3 className="w-4 h-4 mr-2" />
                Edit Profile
              </Button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {[
                { label: "Height", value: userProfile.height },
                { label: "Weight", value: userProfile.weight },
                { label: "Age", value: `${userProfile.age} years` },
                { label: "Gender", value: userProfile.gender },
                { label: "Activity Level", value: userProfile.activityLevel },
                { label: "Primary Goal", value: userProfile.goal },
              ].map((item, index) => (
                <div key={index} className="p-4 bg-secondary/30 rounded-xl">
                  <p className="text-xs text-muted-foreground mb-1">{item.label}</p>
                  <p className="font-semibold">{item.value}</p>
                </div>
              ))}
            </div>

            {/* AI Calculated Stats */}
            <div className="mt-6 p-4 bg-primary/10 border border-primary/20 rounded-xl">
              <div className="flex items-center gap-2 mb-3">
                <Zap className="w-4 h-4 text-primary" />
                <p className="text-sm font-medium text-primary">AI-Calculated Daily Targets</p>
              </div>
              <div className="grid grid-cols-4 gap-4 text-center">
                <div>
                  <p className="text-xl font-bold">2,400</p>
                  <p className="text-xs text-muted-foreground">Calories</p>
                </div>
                <div>
                  <p className="text-xl font-bold">165g</p>
                  <p className="text-xs text-muted-foreground">Protein</p>
                </div>
                <div>
                  <p className="text-xl font-bold">250g</p>
                  <p className="text-xs text-muted-foreground">Carbs</p>
                </div>
                <div>
                  <p className="text-xl font-bold">70g</p>
                  <p className="text-xs text-muted-foreground">Fat</p>
                </div>
              </div>
            </div>
          </div>

          {/* Main Goals */}
          <div className="glass-card rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                <h3 className="text-lg font-semibold">Main Goals</h3>
              </div>
              <Button variant="ghost" size="sm" className="text-muted-foreground">
                <Calendar className="w-4 h-4 mr-2" />
                View Timeline
              </Button>
            </div>

            <div className="space-y-4">
              {mainGoals.map((goal) => (
                <div
                  key={goal.id}
                  className={`p-4 rounded-xl transition-all hover:neon-border cursor-pointer ${
                    goal.progress === 100 ? "bg-green-500/10 border border-green-500/20" : "bg-secondary/30"
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                        goal.progress === 100 ? "bg-green-500/20" : `bg-${goal.color}/20`
                      }`}>
                        {goal.progress === 100 ? (
                          <Check className="w-5 h-5 text-green-400" />
                        ) : (
                          <Flag className={`w-5 h-5 text-${goal.color}`} />
                        )}
                      </div>
                      <div>
                        <p className="font-medium">{goal.title}</p>
                        <p className="text-xs text-muted-foreground">{goal.description}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">
                        {goal.current}<span className="text-muted-foreground font-normal">/{goal.target}</span>
                        <span className="text-xs text-muted-foreground ml-1">{goal.unit}</span>
                      </p>
                      <p className={`text-xs ${goal.progress === 100 ? "text-green-400" : "text-muted-foreground"}`}>
                        {goal.deadline}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          goal.progress === 100 
                            ? "bg-green-500" 
                            : `bg-gradient-to-r from-${goal.color} to-${goal.color}/70`
                        }`}
                        style={{ width: `${goal.progress}%` }}
                      />
                    </div>
                    <span className="text-sm font-medium w-12 text-right">{goal.progress}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Weekly Goals */}
          <div className="glass-card rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-accent" />
                <h3 className="text-lg font-semibold">This Week&apos;s Goals</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                {weeklyGoals.filter(g => g.done).length}/{weeklyGoals.length} completed
              </p>
            </div>

            <div className="space-y-3">
              {weeklyGoals.map((goal, index) => (
                <div
                  key={index}
                  className={`flex items-center justify-between p-4 rounded-xl ${
                    goal.done ? "bg-green-500/10 border border-green-500/20" : "bg-secondary/30"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                      goal.done ? "bg-green-500/20" : "bg-primary/20"
                    }`}>
                      {goal.done ? (
                        <Check className="w-4 h-4 text-green-400" />
                      ) : (
                        <Target className="w-4 h-4 text-primary" />
                      )}
                    </div>
                    <span className={goal.done ? "text-green-400" : ""}>{goal.task}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-muted-foreground">
                      {goal.completed}/{goal.target}
                    </span>
                    <div className="w-20 h-2 bg-secondary rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${goal.done ? "bg-green-500" : "bg-primary"}`}
                        style={{ width: `${(goal.completed / goal.target) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* AI Recommendations */}
          <div className="glass-card rounded-2xl p-6 neon-border">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <h3 className="font-semibold">AI Recommendations</h3>
                <p className="text-xs text-muted-foreground">Personalized suggestions</p>
              </div>
            </div>

            <div className="space-y-3">
              {aiRecommendations.map((rec, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-xl border ${
                    rec.priority === "high"
                      ? "bg-primary/10 border-primary/20"
                      : "bg-secondary/30 border-border/50"
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <p className="font-medium text-sm">{rec.title}</p>
                    {rec.priority === "high" && (
                      <span className="px-2 py-0.5 text-xs bg-primary/20 text-primary rounded-full">Priority</span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">{rec.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Progress Summary */}
          <div className="glass-card rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-6">
              <TrendingUp className="w-5 h-5 text-green-400" />
              <h3 className="font-semibold">Progress Summary</h3>
            </div>

            <div className="space-y-4">
              <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-xl">
                <p className="text-sm font-medium text-green-400 mb-1">On Track</p>
                <p className="text-xs text-muted-foreground">You&apos;re progressing faster than projected toward your goals!</p>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Weight Goal</span>
                  <span className="text-sm font-medium text-green-400">+12% ahead</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Body Fat Goal</span>
                  <span className="text-sm font-medium text-green-400">+8% ahead</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Strength Goals</span>
                  <span className="text-sm font-medium text-primary">On track</span>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="glass-card rounded-2xl p-6">
            <h3 className="font-semibold mb-4">Quick Actions</h3>
            <div className="space-y-2">
              {[
                { label: "Update Weight", icon: Target },
                { label: "Take Progress Photo", icon: Calendar },
                { label: "Adjust Goals", icon: Edit3 },
                { label: "View Projections", icon: TrendingUp },
              ].map((action, index) => (
                <button
                  key={index}
                  className="w-full flex items-center justify-between p-3 rounded-xl bg-secondary/30 hover:bg-secondary/50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <action.icon className="w-4 h-4 text-primary" />
                    <span className="text-sm">{action.label}</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
