import { AIChat } from "@/components/dashboard/ai-chat"

export default function ChatPage() {
  return (
    <div className="h-screen">
      <AIChat />
    </div>
  )
}
