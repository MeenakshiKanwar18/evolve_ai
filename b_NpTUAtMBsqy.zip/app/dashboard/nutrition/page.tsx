"use client"

import { useState } from "react"
import { Apple, Beef, Camera, ChevronRight, Droplet, Flame, Plus, Salad, Sparkles, Target, Utensils, Wheat, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"

const macroData = {
  calories: { current: 1847, target: 2400, unit: "kcal" },
  protein: { current: 142, target: 165, unit: "g" },
  carbs: { current: 187, target: 250, unit: "g" },
  fat: { current: 58, target: 70, unit: "g" },
  water: { current: 8, target: 12, unit: "glasses" },
}

const meals = [
  {
    name: "Breakfast",
    time: "7:30 AM",
    calories: 485,
    protein: 35,
    carbs: 52,
    fat: 14,
    items: [
      { name: "Oatmeal with Banana", amount: "1 bowl", calories: 280 },
      { name: "Scrambled Eggs", amount: "3 eggs", calories: 205 },
    ]
  },
  {
    name: "Morning Snack",
    time: "10:00 AM",
    calories: 180,
    protein: 25,
    carbs: 8,
    fat: 4,
    items: [
      { name: "Protein Shake", amount: "1 scoop", calories: 180 },
    ]
  },
  {
    name: "Lunch",
    time: "12:30 PM",
    calories: 620,
    protein: 48,
    carbs: 65,
    fat: 18,
    items: [
      { name: "Grilled Chicken Breast", amount: "200g", calories: 330 },
      { name: "Brown Rice", amount: "1 cup", calories: 215 },
      { name: "Mixed Vegetables", amount: "1 cup", calories: 75 },
    ]
  },
  {
    name: "Afternoon Snack",
    time: "3:30 PM",
    calories: 210,
    protein: 18,
    carbs: 15,
    fat: 10,
    items: [
      { name: "Greek Yogurt", amount: "1 cup", calories: 130 },
      { name: "Almonds", amount: "15 pieces", calories: 80 },
    ]
  },
  {
    name: "Dinner",
    time: "7:00 PM",
    calories: 0,
    protein: 0,
    carbs: 0,
    fat: 0,
    items: [],
    upcoming: true
  },
]

const suggestedMeals = [
  {
    name: "Salmon & Quinoa Bowl",
    calories: 580,
    protein: 45,
    carbs: 48,
    fat: 22,
    prepTime: "25 min",
    image: "bg-gradient-to-br from-primary/30 to-accent/30"
  },
  {
    name: "Lean Beef Stir Fry",
    calories: 520,
    protein: 42,
    carbs: 35,
    fat: 18,
    prepTime: "20 min",
    image: "bg-gradient-to-br from-accent/30 to-primary/30"
  },
  {
    name: "Chicken Caesar Salad",
    calories: 450,
    protein: 38,
    carbs: 18,
    fat: 24,
    prepTime: "15 min",
    image: "bg-gradient-to-br from-primary/20 to-accent/20"
  },
]

export default function NutritionPage() {
  const [expandedMeal, setExpandedMeal] = useState<number | null>(null)

  const caloriePercentage = (macroData.calories.current / macroData.calories.target) * 100

  return (
    <div className="p-6 lg:p-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold">Nutrition</h1>
          <p className="text-muted-foreground">AI-powered meal tracking and recommendations</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="glass-card border-border/50">
            <Camera className="w-4 h-4 mr-2" />
            Scan Food
          </Button>
          <Button className="neon-glow bg-primary hover:bg-primary/90">
            <Plus className="w-4 h-4 mr-2" />
            Log Meal
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Calorie Overview */}
          <div className="glass-card rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-lg font-semibold">Daily Overview</h2>
                <p className="text-sm text-muted-foreground">Track your nutrition progress</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold">{macroData.calories.current}</p>
                <p className="text-sm text-muted-foreground">/ {macroData.calories.target} kcal</p>
              </div>
            </div>

            {/* Big Calorie Ring */}
            <div className="flex items-center justify-center mb-8">
              <div className="relative w-48 h-48">
                <svg className="w-full h-full transform -rotate-90">
                  <circle
                    cx="96"
                    cy="96"
                    r="84"
                    fill="none"
                    stroke="rgba(139, 92, 246, 0.1)"
                    strokeWidth="16"
                  />
                  <circle
                    cx="96"
                    cy="96"
                    r="84"
                    fill="none"
                    stroke="url(#calorieGradient)"
                    strokeWidth="16"
                    strokeLinecap="round"
                    strokeDasharray={`${(caloriePercentage / 100) * 528} 528`}
                    className="transition-all duration-1000"
                  />
                  <defs>
                    <linearGradient id="calorieGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="hsl(270, 80%, 60%)" />
                      <stop offset="100%" stopColor="hsl(280, 70%, 55%)" />
                    </linearGradient>
                  </defs>
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-4xl font-bold">{Math.round(caloriePercentage)}%</span>
                  <span className="text-sm text-muted-foreground">of daily goal</span>
                </div>
              </div>
            </div>

            {/* Macro Breakdown */}
            <div className="grid grid-cols-4 gap-4">
              {[
                { name: "Protein", icon: Beef, data: macroData.protein, color: "primary" },
                { name: "Carbs", icon: Wheat, data: macroData.carbs, color: "accent" },
                { name: "Fat", icon: Droplet, data: macroData.fat, color: "chart-3" },
                { name: "Water", icon: Droplet, data: macroData.water, color: "chart-4" },
              ].map((macro) => (
                <div key={macro.name} className="text-center">
                  <div className={`w-12 h-12 rounded-xl bg-${macro.color}/20 flex items-center justify-center mx-auto mb-2`}>
                    <macro.icon className={`w-5 h-5 text-${macro.color}`} />
                  </div>
                  <p className="text-lg font-bold">
                    {macro.data.current}
                    <span className="text-xs font-normal text-muted-foreground">/{macro.data.target}</span>
                  </p>
                  <p className="text-xs text-muted-foreground">{macro.name}</p>
                  <div className="h-1.5 bg-secondary rounded-full mt-2 overflow-hidden">
                    <div 
                      className={`h-full bg-${macro.color} rounded-full`}
                      style={{ width: `${Math.min((macro.data.current / macro.data.target) * 100, 100)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Today's Meals */}
          <div className="glass-card rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold">Today&apos;s Meals</h2>
              <Button variant="ghost" size="sm" className="text-muted-foreground">
                View History
              </Button>
            </div>

            <div className="space-y-3">
              {meals.map((meal, index) => (
                <div
                  key={index}
                  className={`rounded-xl transition-all ${
                    meal.upcoming 
                      ? "border-2 border-dashed border-border/50 bg-secondary/10" 
                      : "bg-secondary/30 hover:bg-secondary/50"
                  }`}
                >
                  <button
                    onClick={() => setExpandedMeal(expandedMeal === index ? null : index)}
                    className="w-full p-4 flex items-center justify-between"
                  >
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                        meal.upcoming ? "bg-secondary/50" : "bg-primary/20"
                      }`}>
                        {meal.upcoming ? (
                          <Plus className="w-5 h-5 text-muted-foreground" />
                        ) : (
                          <Utensils className="w-5 h-5 text-primary" />
                        )}
                      </div>
                      <div className="text-left">
                        <p className="font-medium">{meal.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {meal.upcoming ? "Plan your dinner" : `${meal.time} • ${meal.items.length} items`}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      {!meal.upcoming && (
                        <div className="text-right">
                          <p className="font-semibold text-primary">{meal.calories}</p>
                          <p className="text-xs text-muted-foreground">kcal</p>
                        </div>
                      )}
                      <ChevronRight className={`w-4 h-4 text-muted-foreground transition-transform ${
                        expandedMeal === index ? "rotate-90" : ""
                      }`} />
                    </div>
                  </button>

                  {expandedMeal === index && !meal.upcoming && (
                    <div className="px-4 pb-4 pt-2 border-t border-border/50 mx-4">
                      <div className="grid grid-cols-3 gap-4 mb-4 text-center text-sm">
                        <div>
                          <p className="font-semibold">{meal.protein}g</p>
                          <p className="text-xs text-muted-foreground">Protein</p>
                        </div>
                        <div>
                          <p className="font-semibold">{meal.carbs}g</p>
                          <p className="text-xs text-muted-foreground">Carbs</p>
                        </div>
                        <div>
                          <p className="font-semibold">{meal.fat}g</p>
                          <p className="text-xs text-muted-foreground">Fat</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        {meal.items.map((item, itemIndex) => (
                          <div key={itemIndex} className="flex items-center justify-between text-sm py-2 border-b border-border/30 last:border-0">
                            <span>{item.name}</span>
                            <span className="text-muted-foreground">{item.amount} • {item.calories} kcal</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* AI Recommendation */}
          <div className="glass-card rounded-2xl p-6 neon-border">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-primary-foreground" />
              </div>
              <h3 className="font-semibold">AI Recommendation</h3>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Based on your workout today and current macros, I recommend a high-protein dinner to hit your daily targets.
            </p>
            <div className="p-3 bg-primary/10 rounded-xl text-sm">
              <p className="font-medium text-primary mb-1">Remaining for today:</p>
              <div className="grid grid-cols-2 gap-2 text-muted-foreground">
                <span>553 kcal</span>
                <span>23g protein</span>
                <span>63g carbs</span>
                <span>12g fat</span>
              </div>
            </div>
          </div>

          {/* Suggested Dinners */}
          <div className="glass-card rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-4">
              <Target className="w-5 h-5 text-primary" />
              <h3 className="font-semibold">Suggested Dinners</h3>
            </div>
            <div className="space-y-3">
              {suggestedMeals.map((meal, index) => (
                <div key={index} className="group cursor-pointer">
                  <div className="flex gap-3 p-3 rounded-xl bg-secondary/30 hover:bg-secondary/50 transition-all">
                    <div className={`w-16 h-16 rounded-xl ${meal.image} flex items-center justify-center shrink-0`}>
                      <Salad className="w-6 h-6 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{meal.name}</p>
                      <p className="text-xs text-muted-foreground">{meal.prepTime}</p>
                      <div className="flex gap-2 mt-1 text-xs text-muted-foreground">
                        <span>{meal.calories} kcal</span>
                        <span>•</span>
                        <span>{meal.protein}g protein</span>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-muted-foreground self-center opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Add */}
          <div className="glass-card rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-4">
              <Zap className="w-5 h-5 text-accent" />
              <h3 className="font-semibold">Quick Add</h3>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {[
                { name: "Water", icon: Droplet, color: "chart-4" },
                { name: "Protein Shake", icon: Apple, color: "primary" },
                { name: "Snack", icon: Apple, color: "accent" },
                { name: "Custom", icon: Plus, color: "muted-foreground" },
              ].map((item) => (
                <button
                  key={item.name}
                  className="flex flex-col items-center gap-2 p-3 rounded-xl bg-secondary/30 hover:bg-secondary/50 transition-all"
                >
                  <item.icon className={`w-5 h-5 text-${item.color}`} />
                  <span className="text-xs">{item.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
