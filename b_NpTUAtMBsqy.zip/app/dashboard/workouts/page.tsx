"use client"

import { useState } from "react"
import { Calendar, Check, ChevronRight, Clock, Dumbbell, Flame, Play, Plus, RotateCcw, Target, TrendingUp, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"

const weeklySchedule = [
  { day: "Mon", name: "Push", focus: "Chest & Triceps", completed: true },
  { day: "Tue", name: "Pull", focus: "Back & Biceps", completed: true },
  { day: "Wed", name: "Legs", focus: "Quads & Glutes", completed: true },
  { day: "Thu", name: "Rest", focus: "Active Recovery", completed: true },
  { day: "Fri", name: "Push", focus: "Shoulders & Chest", completed: false, isToday: true },
  { day: "Sat", name: "Pull", focus: "Back & Arms", completed: false },
  { day: "Sun", name: "Rest", focus: "Full Recovery", completed: false },
]

const todaysExercises = [
  { 
    name: "Overhead Press", 
    sets: [
      { weight: 95, reps: 10, completed: true },
      { weight: 105, reps: 8, completed: true },
      { weight: 115, reps: 6, completed: false },
      { weight: 115, reps: 6, completed: false },
    ],
    rest: "90s",
    muscle: "Shoulders"
  },
  { 
    name: "Incline Bench Press", 
    sets: [
      { weight: 135, reps: 10, completed: false },
      { weight: 155, reps: 8, completed: false },
      { weight: 165, reps: 6, completed: false },
    ],
    rest: "90s",
    muscle: "Upper Chest"
  },
  { 
    name: "Lateral Raises", 
    sets: [
      { weight: 20, reps: 15, completed: false },
      { weight: 20, reps: 15, completed: false },
      { weight: 20, reps: 15, completed: false },
    ],
    rest: "45s",
    muscle: "Side Delts"
  },
  { 
    name: "Cable Flyes", 
    sets: [
      { weight: 30, reps: 12, completed: false },
      { weight: 30, reps: 12, completed: false },
      { weight: 30, reps: 12, completed: false },
    ],
    rest: "45s",
    muscle: "Chest"
  },
  { 
    name: "Face Pulls", 
    sets: [
      { weight: 40, reps: 15, completed: false },
      { weight: 40, reps: 15, completed: false },
      { weight: 40, reps: 15, completed: false },
    ],
    rest: "45s",
    muscle: "Rear Delts"
  },
]

const personalRecords = [
  { exercise: "Bench Press", weight: 225, reps: 8, date: "2 days ago" },
  { exercise: "Squat", weight: 275, reps: 5, date: "1 week ago" },
  { exercise: "Deadlift", weight: 315, reps: 5, date: "5 days ago" },
  { exercise: "Overhead Press", weight: 135, reps: 5, date: "3 days ago" },
]

export default function WorkoutsPage() {
  const [selectedExercise, setSelectedExercise] = useState(0)
  
  const totalSets = todaysExercises.reduce((acc, ex) => acc + ex.sets.length, 0)
  const completedSets = todaysExercises.reduce((acc, ex) => 
    acc + ex.sets.filter(s => s.completed).length, 0
  )

  return (
    <div className="p-6 lg:p-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold">Workouts</h1>
          <p className="text-muted-foreground">AI-optimized training program</p>
        </div>
        <Button className="neon-glow bg-primary hover:bg-primary/90">
          <Plus className="w-4 h-4 mr-2" />
          Custom Workout
        </Button>
      </div>

      {/* Weekly Schedule */}
      <div className="glass-card rounded-2xl p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">This Week</h2>
          <Button variant="ghost" size="sm" className="text-muted-foreground">
            <Calendar className="w-4 h-4 mr-2" />
            View Calendar
          </Button>
        </div>
        <div className="grid grid-cols-7 gap-2">
          {weeklySchedule.map((day, index) => (
            <div
              key={index}
              className={`text-center p-3 rounded-xl transition-all ${
                day.isToday 
                  ? "bg-primary/20 border border-primary/50 neon-border" 
                  : day.completed 
                    ? "bg-secondary/50" 
                    : "bg-secondary/20"
              }`}
            >
              <p className="text-xs text-muted-foreground mb-1">{day.day}</p>
              <p className={`text-sm font-semibold ${day.isToday ? "text-primary" : ""}`}>{day.name}</p>
              <p className="text-xs text-muted-foreground truncate">{day.focus}</p>
              {day.completed && (
                <div className="mt-2 w-5 h-5 rounded-full bg-green-500/20 flex items-center justify-center mx-auto">
                  <Check className="w-3 h-3 text-green-400" />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Today's Workout */}
        <div className="lg:col-span-2 glass-card rounded-2xl p-6">
          <div className="flex items-start justify-between mb-6">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h2 className="text-lg font-semibold">Today&apos;s Workout</h2>
                <span className="px-2 py-0.5 text-xs bg-primary/20 text-primary rounded-full">Push Day</span>
              </div>
              <p className="text-sm text-muted-foreground">Shoulders & Chest Focus</p>
            </div>
            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center gap-1 text-muted-foreground">
                <Clock className="w-4 h-4" />
                <span>~55 min</span>
              </div>
              <div className="flex items-center gap-1 text-muted-foreground">
                <Flame className="w-4 h-4" />
                <span>~380 kcal</span>
              </div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="mb-6">
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-muted-foreground">Progress</span>
              <span className="font-medium">{completedSets}/{totalSets} sets</span>
            </div>
            <div className="h-2 bg-secondary rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-primary to-accent rounded-full transition-all duration-500"
                style={{ width: `${(completedSets / totalSets) * 100}%` }}
              />
            </div>
          </div>

          {/* Exercise List */}
          <div className="space-y-3">
            {todaysExercises.map((exercise, index) => {
              const exerciseCompleted = exercise.sets.filter(s => s.completed).length
              const isActive = index === selectedExercise
              
              return (
                <div
                  key={index}
                  onClick={() => setSelectedExercise(index)}
                  className={`p-4 rounded-xl cursor-pointer transition-all ${
                    isActive 
                      ? "bg-primary/10 border border-primary/30 neon-border" 
                      : "bg-secondary/30 hover:bg-secondary/50"
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                        exerciseCompleted === exercise.sets.length 
                          ? "bg-green-500/20" 
                          : "bg-primary/20"
                      }`}>
                        {exerciseCompleted === exercise.sets.length ? (
                          <Check className="w-5 h-5 text-green-400" />
                        ) : (
                          <Dumbbell className="w-5 h-5 text-primary" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium">{exercise.name}</p>
                        <p className="text-xs text-muted-foreground">{exercise.muscle} • Rest: {exercise.rest}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">
                        {exerciseCompleted}/{exercise.sets.length}
                      </span>
                      <ChevronRight className={`w-4 h-4 transition-transform ${isActive ? "rotate-90" : ""}`} />
                    </div>
                  </div>

                  {isActive && (
                    <div className="space-y-2 mt-4 pt-4 border-t border-border/50">
                      {exercise.sets.map((set, setIndex) => (
                        <div 
                          key={setIndex} 
                          className={`flex items-center justify-between p-3 rounded-lg ${
                            set.completed ? "bg-green-500/10" : "bg-secondary/50"
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <span className="text-sm text-muted-foreground w-8">Set {setIndex + 1}</span>
                            <span className="text-sm font-medium">{set.weight} lbs × {set.reps}</span>
                          </div>
                          <Button 
                            size="sm" 
                            variant={set.completed ? "ghost" : "default"}
                            className={set.completed ? "text-green-400" : "neon-glow bg-primary hover:bg-primary/90"}
                          >
                            {set.completed ? (
                              <>
                                <Check className="w-4 h-4 mr-1" />
                                Done
                              </>
                            ) : (
                              <>
                                <Play className="w-4 h-4 mr-1" />
                                Start
                              </>
                            )}
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )
            })}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 mt-6">
            <Button className="flex-1 neon-glow bg-primary hover:bg-primary/90">
              <Play className="w-4 h-4 mr-2" />
              Continue Workout
            </Button>
            <Button variant="outline" className="glass-card border-border/50">
              <RotateCcw className="w-4 h-4 mr-2" />
              Reset
            </Button>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* AI Insights */}
          <div className="glass-card rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <Zap className="w-4 h-4 text-primary-foreground" />
              </div>
              <h3 className="font-semibold">AI Insights</h3>
            </div>
            <div className="space-y-3 text-sm">
              <div className="p-3 bg-green-500/10 border border-green-500/20 rounded-xl">
                <p className="text-green-400 font-medium mb-1">Great Recovery!</p>
                <p className="text-muted-foreground">Your HRV indicates you&apos;re well-rested. Consider pushing heavier today.</p>
              </div>
              <div className="p-3 bg-primary/10 border border-primary/20 rounded-xl">
                <p className="text-primary font-medium mb-1">Progressive Overload</p>
                <p className="text-muted-foreground">Try adding 5 lbs to your overhead press based on last week&apos;s performance.</p>
              </div>
            </div>
          </div>

          {/* Personal Records */}
          <div className="glass-card rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-4">
              <Target className="w-5 h-5 text-primary" />
              <h3 className="font-semibold">Personal Records</h3>
            </div>
            <div className="space-y-3">
              {personalRecords.map((pr, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-secondary/30 rounded-xl">
                  <div>
                    <p className="text-sm font-medium">{pr.exercise}</p>
                    <p className="text-xs text-muted-foreground">{pr.date}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-primary">{pr.weight} lbs</p>
                    <p className="text-xs text-muted-foreground">× {pr.reps} reps</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Weekly Stats */}
          <div className="glass-card rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="w-5 h-5 text-accent" />
              <h3 className="font-semibold">This Week</h3>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-secondary/30 rounded-xl">
                <p className="text-2xl font-bold text-primary">4</p>
                <p className="text-xs text-muted-foreground">Workouts</p>
              </div>
              <div className="text-center p-3 bg-secondary/30 rounded-xl">
                <p className="text-2xl font-bold text-accent">12,840</p>
                <p className="text-xs text-muted-foreground">Volume (lbs)</p>
              </div>
              <div className="text-center p-3 bg-secondary/30 rounded-xl">
                <p className="text-2xl font-bold">3h 42m</p>
                <p className="text-xs text-muted-foreground">Total Time</p>
              </div>
              <div className="text-center p-3 bg-secondary/30 rounded-xl">
                <p className="text-2xl font-bold text-green-400">1,520</p>
                <p className="text-xs text-muted-foreground">Calories</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
